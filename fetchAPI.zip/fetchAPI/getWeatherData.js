

// Load environment variables

const axios = require('axios');
const { Client } = require('pg');

// Step 1: Fetch Data from Open-Meteo API
const fetchData = async () => {
    const api_url = "https://api.open-meteo.com/v1/forecast?latitude=51.5085&longitude=-0.1257&hourly=temperature_2m,relative_humidity_2m";
    try {
        const response = await axios.get(api_url);
        const data = response.data;
        console.log("Data fetched from Open-Meteo API.");
        return data.hourly;
    } catch (error) {
        console.error("Error fetching data from Open-Meteo API:", error);
        return null;
    }
};

// Step 2: Connect to Neon DB and Insert Data
const insertData = async (timestamps, temperatures, humidities) => {
    const client = new Client({
      user: "neondb_owner",
      host: "ep-floral-lab-a1d23837-pooler.ap-southeast-1.aws.neon.tech",
      database: "weather_db",
      password: "npg_l6T7pDKytxVX",
      port: 5432,
        ssl: {
            rejectUnauthorized: false
        }
    });

    try {
        await client.connect();
        console.log("Connected to Neon DB.");

        for (let i = 0; i < timestamps.length; i++) {
            const timestamp = timestamps[i];
            const temperature = temperatures[i];
            const humidity = humidities[i];

            // Insert data into the weather_data table
            await client.query(
                `INSERT INTO weather_data (timestamp, temperature, humidity) VALUES ($1, $2, $3)`,
                [timestamp, temperature, humidity]
            );
            console.log(`Inserted data for ${timestamp}`);
        }
    } catch (error) {
        console.error("Error inserting data into Neon DB:", error);
    } finally {
        await client.end();
        console.log("Disconnected from Neon DB.");
    }
};

// Main Function
const main = async () => {
    const hourlyData = await fetchData();
    if (hourlyData) {
        const timestamps = hourlyData.time;
        const temperatures = hourlyData.temperature_2m;
        const humidities = hourlyData.relative_humidity_2m;
        await insertData(timestamps, temperatures, humidities);
    }
};

// Execute Main Function
main();



          