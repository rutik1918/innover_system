package com.example.model.weather.repo;
import com.example.model.weather.model.weatherData;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface weatherDataRepository extends JpaRepository<weatherData, Long> {
    List<weatherData> findTop10ByOrderByTimestampDesc();
}
