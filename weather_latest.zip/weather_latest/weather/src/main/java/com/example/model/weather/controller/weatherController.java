package com.example.model.weather.controller;
import com.example.model.weather.model.weatherData;

import com.example.model.weather.service.weatherService;

import com.example.model.weather.repo.weatherDataRepository ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/weather")
public class weatherController {

    @Autowired
    private weatherService weatherservice;

    // Fetch and return data from Neon DB
    @GetMapping("/recent")
    public List<weatherData> getRecentData() {
        List<weatherData> dataList = weatherservice.getRecentData();
        // Publish to ThingsBoard
        dataList.forEach(weatherservice::publishToThingsBoard);
        return dataList;
    }
}
