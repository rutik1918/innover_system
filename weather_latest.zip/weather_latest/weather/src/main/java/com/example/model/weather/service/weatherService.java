package com.example.model.weather.service;
import com.example.model.weather.model.weatherData;


import com.example.model.weather.repo.weatherDataRepository ;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.List;

@Service
public class weatherService {

    private final weatherDataRepository repository;
    private final RestTemplate restTemplate;

    @Value("${thingsboard.url}")
    private String thingsboardUrl;

    @Value("${thingsboard.device.token}")
    private String deviceToken;

    public weatherService(weatherDataRepository repository) {
        this.repository = repository;
        this.restTemplate = new RestTemplate();
    }

    // Fetch last 10 records from Neon DB
    public List<weatherData> getRecentData() {
        return repository.findTop10ByOrderByTimestampDesc();
    }

    // Publish data to ThingsBoard
    public void publishToThingsBoard(weatherData data) {
        String url = thingsboardUrl + "/api/v1/" + deviceToken + "/telemetry";
        String payload = String.format("{\"temperature\": %s, \"humidity\": %s}",
                data.getTemperature(),
                data.getHumidity());
        restTemplate.postForObject(url, payload, String.class);
    }
}
